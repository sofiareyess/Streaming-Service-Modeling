#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include "Video.h"
#include "Episodio.h"
#include "Pelicula.h"
#include "Serie.h"

void leerArchivo(const std::string& archivo, std::vector<Video*>& videos, std::vector<Pelicula*>& peliculas, std::vector<Episodio*>& episodios, std::vector<Serie>& series, int& contadorVideos, int& contadorPeliculas, int& contadorEpisodios) {
    std::string direccion = "/Users/arodarana/CLionProjects/Reto/";
    direccion += archivo;
    std::ifstream archivoEntrada(direccion);
    if (!archivoEntrada) {
        std::cerr << "Error al abrir el archivo " << archivo << std::endl;
        return;
    }

    std::cout << "Archivo leido con exito!" << std::endl;

    std::string linea;
    std::getline(archivoEntrada, linea);

    while (std::getline(archivoEntrada, linea)) {
        std::istringstream ss(linea);
        std::string tipo, titulo, genero, tituloSerie;
        int id, duracion, episodio, temporada;
        double calificacion;

        ss >> tipo >> id >> titulo >> genero >> duracion >> calificacion >> tituloSerie >> episodio >> temporada;

        if (tipo == "p") {
            Pelicula* p = new Pelicula(id, titulo, genero, duracion, calificacion);
            peliculas.push_back(p);
            videos.push_back(p);
            contadorPeliculas++;
            contadorVideos++;
        } else if (tipo == "e") {
            Episodio* e = new Episodio(id, titulo, genero, duracion, calificacion, tituloSerie, episodio, temporada);
            episodios.push_back(e);
            videos.push_back(e);
            contadorEpisodios++;
            contadorVideos++;

            bool serieEncontrada = false;
            for (auto& serie : series) {
                if (serie.getTituloSerie() == tituloSerie) {
                    serie.agregarEpisodio(*e);
                    serieEncontrada = true;
                    break;
                }
            }

            if (!serieEncontrada) {
                Serie nuevaSerie(tituloSerie, genero);
                nuevaSerie.agregarEpisodio(*e);
                series.push_back(nuevaSerie);
            }
        }
    }
std::cout << "Se han cargado " << contadorVideos << " videos, de los cuales " << contadorPeliculas << " son películas y " << contadorEpisodios << " son episodios." << std::endl;
    archivoEntrada.close();
}

void calificarVideo(std::vector<Video*>& videos) {
    std::string titulo;
    double calificacion;

    std::cout << "Título del video: ";
    std::cin >> titulo;
    std::cout << "Calificación: ";
    std::cin >> calificacion;

    for (auto video : videos) {
        if (video->getTitulo() == titulo) {
            video->setCalificacion(calificacion);
            break;
        }
    }
}

int main() {
    int opcion;
    int contadorVideos = 0;
    int contadorPeliculas = 0;
    int contadorEpisodios = 0;

    std::vector<Video *> videos;
    std::vector<Pelicula *> peliculas;
    std::vector<Episodio *> episodios;
    std::vector<Serie> series;

    do {
        std::cout << "+------ Elije una opcion -----+" << std::endl;
        std::cout << "| 1. Cargar archivo de datos  |" << std::endl;
        std::cout << "| 2. Mostrar videos           |" << std::endl;
        std::cout << "| 3. Mostrar episodios        |" << std::endl;
        std::cout << "| 4. Mostrar peliculas        |" << std::endl;
        std::cout << "| 5. Mostrar series           |" << std::endl;
        std::cout << "| 6. Calificar un video       |" << std::endl;
        std::cout << "| 0. Salir                    |" << std::endl;
        std::cout << "+-----------------------------+" << std::endl;
        std::cout << "Opción: ";
        std::cin >> opcion;

        switch (opcion) {
            case 1: {
                std::string nombreArchivo;
                std::cout << "Nombre del archivo: ";
                std::cin >> nombreArchivo;

                leerArchivo(nombreArchivo, videos, peliculas, episodios, series, contadorVideos, contadorPeliculas,
                            contadorEpisodios);
                break;
            }
            case 2:
                int opcion;
                std::cout << "Por calificacion (1) o por genero (2):" << std::endl;
                std::cin >> opcion;
                if (opcion == 1) {
                    double calificacionn;
                    std::cout << "Videos con calificacion: ";
                    std::cin >> calificacionn;
                    std::cout << "Mostrando videos:" << std::endl;
                    for (auto video: videos) {
                        if (video->getCalificacion() == calificacionn)
                            video->mostrarVideos();
                        std::cout << "----" << std::endl;
                    }
                } else if (opcion == 2) {
                    std::string genero;
                    std::cout << "Videos con genero: ";
                    std::cin >> genero;
                    std::cout << "Mostrando videos:" << std::endl;
                    for (auto video: videos) {
                        if (video->getGenero() == genero)
                            video->mostrarVideos();
                        std::cout << "----" << std::endl;
                    }
                }
                break;
            case 3: {
                std::string tituloSeriee;
                double calificacionn;

                std::cout << "Episodios de la serie: ";
                std::cin >> tituloSeriee;
                std::cout << "Episodios con calificacion: ";
                std::cin >> calificacionn;

                for (auto &serie: series) {
                    if (serie.getTituloSerie() == tituloSeriee) {
                        serie.mostrarEpisodiosDeSerie(tituloSeriee, episodios, calificacionn);
                        break;
                    }
                }
                break;
            }
            case 4:
                double calificacionnn;
                std::cout << "Pelliculas con calificacion: ";
                std::cin >> calificacionnn;
                std::cout << "Mostrando peliculas:" << std::endl;
                for (auto pelicula: peliculas) {
                    if (pelicula->getCalificacion() == calificacionnn)
                        pelicula->mostrarVideos();
                    std::cout << "----" << std::endl;
                }
                break;
                case 5:
                    std::cout << "Mostrando series:" << std::endl;
                for (const auto &serie: series) {
                    serie.mostrarSerie();
                    std::cout << "----" << std::endl;
                }
                break;
                case 6:
                    std::cout << "Calificar un video:" << std::endl;
                calificarVideo(videos);
                break;
                case 0:
                    std::cout << "Saliendo..." << std::endl;
                break;
                default:
                    std::cout << "Opción inválida" << std::endl;
                break;
            }
        }
        while (opcion != 0);

        for (auto video: videos) {
            delete video;
        }
        for (auto episodio: episodios) {
            delete episodio;
        }
        videos.clear();
        peliculas.clear();
        episodios.clear();

        return 0;
    }