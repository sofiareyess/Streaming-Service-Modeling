#include "Pelicula.h"

Pelicula::Pelicula(const int id, const std::string& titulo, const std::string& genero, const int duracion, double calificacion) : Video(tipo, id, titulo, genero, duracion, calificacion){}

double Pelicula::getCalificacion() const {
    return calificacion;
}

void Pelicula::mostrarVideos() const {
    Video::mostrarVideos();
    std::cout << "[Película]" << std::endl;
}