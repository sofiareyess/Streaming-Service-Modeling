#ifndef EPISODIO_H
#define EPISODIO_H

#include "Video.h"

class Episodio : public Video {
private:
    std::string tituloSerie;
    int episodio;
    int temporada;

public:
    Episodio(int id, const std::string& titulo, const std::string& genero, int duracion, double calificacion, const std::string& tituloSerie, int episodio, int temporada);

    void mostrarVideos() const override;
    double getCalificacion() const;
};

#endif
