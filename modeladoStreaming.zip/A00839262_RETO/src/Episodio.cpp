#include "Episodio.h"

Episodio::Episodio(int id, const std::string& titulo, const std::string& genero, int duracion, double calificacion, const std::string& tituloSerie, int episodio, int temporada)
        : Video("e", id, titulo, genero, duracion, calificacion), tituloSerie(tituloSerie), episodio(episodio), temporada(temporada) {}

void Episodio::mostrarVideos() const {
    Video::mostrarVideos();
    std::cout << "Título Serie: " << tituloSerie << "\n"
              << "Episodio: " << episodio << "\n"
              << "Temporada: " << temporada << "\n"
              << "[Episodio]" << std::endl;
}

double Episodio::getCalificacion() const {
    return calificacion;
}
