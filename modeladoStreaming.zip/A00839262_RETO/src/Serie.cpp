#include "Serie.h"

Serie::Serie(const std::string& tituloSerie, const std::string& genero)
        : tituloSerie(tituloSerie), genero(genero) {}

std::string Serie::getTituloSerie() const {
    return tituloSerie;
}

void Serie::mostrarEpisodiosDeSerie(std::string tituloSerie, std::vector<Episodio*> episodios, double const calificacion) {
    std::cout << "Episodios de la serie " << tituloSerie << " con calificación: " << calificacion << ":\n";
    for (const auto& episodio : episodios) {
        if (episodio->getCalificacion() == calificacion) {
            episodio->mostrarVideos();
            std::cout << "----\n";
        }
    }
}

void Serie::agregarEpisodio(const Episodio& episodio) {
    episodios.push_back(episodio);
}

void Serie::mostrarSerie() const {
    std::cout << "Serie: " << tituloSerie << "\n"
              << "Género: " << genero << "\n"
              << "Calificación Promedio: " << calcularCalificacionPromedio() << "\n"
              << "Episodios:\n";
    for (const auto& episodio : episodios) {
        episodio.mostrarVideos();
        std::cout << "----\n";
    }
}

double Serie::calcularCalificacionPromedio() const {
    if (episodios.empty()) return 0.0;

    double sumaCalificaciones = 0.0;
    for (const auto& episodio : episodios) {
        sumaCalificaciones += episodio.getCalificacion();
    }
    return sumaCalificaciones / episodios.size();
}