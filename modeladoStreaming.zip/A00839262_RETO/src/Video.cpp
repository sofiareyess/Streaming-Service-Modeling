#include "Video.h"

Video::Video() {
    tipo = "";
    id = 0;
    titulo = "";
    genero = "";
    duracion = 0;
    calificacion = 0.0;

}

Video::Video(const std::string& tipo, const int id, const std::string& titulo, const std::string& genero, const int duracion, double calificacion) {
    this -> tipo = tipo;
    this -> id = id;
    this -> titulo = titulo;
    this -> genero = genero;
    this -> duracion = duracion;
    this -> calificacion = calificacion;
}

double Video::getCalificacion() const {
    return calificacion;
}

std::string Video::getGenero() const {
    return genero;
}

void Video::setCalificacion(double calificacion) {
    this -> calificacion = calificacion;
}

std::string Video::getTipo() const {
    return tipo;
}

std::string Video::getTitulo() const {
    return titulo;
}

void Video::mostrarVideos() const {
    std::cout << "ID: " << id << "\n"
         << "Título: " << titulo << "\n"
         << "Género: " << genero << "\n"
         << "Duración: " << duracion << " minutos" << "\n"
         << "Calificación: " << calificacion << "\n";
}