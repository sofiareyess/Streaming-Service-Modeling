#ifndef PELICULA_H
#define PELICULA_H

#include "Video.h"

class Pelicula : public Video {
public:
    Pelicula(int, const std::string&, const std::string&, int, double);

    double getCalificacion() const;

    void mostrarVideos() const override;
};
#endif