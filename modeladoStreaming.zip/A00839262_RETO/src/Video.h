#ifndef VIDEO_H
#define VIDEO_H

#include <string>
#include <iostream>

class Video {
protected:
    std::string tipo, titulo, genero;
    int id, duracion;
    double calificacion;

public:
    Video();
    Video(const std::string&, int, const std::string&, const std::string&, int, double);
    virtual ~Video() = default;

    double getCalificacion() const;
    std::string getGenero() const;

    void setCalificacion(double);

    std::string getTipo() const;
    std::string getTitulo() const;

    virtual void mostrarVideos() const;
};

#endif
