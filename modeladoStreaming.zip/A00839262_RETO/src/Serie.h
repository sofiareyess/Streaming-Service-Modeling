#ifndef SERIE_H
#define SERIE_H

#include <vector>
#include "Episodio.h"

class Serie {
private:
    std::string tituloSerie;
    std::string genero;
    std::vector<Episodio> episodios;

public:
    Serie(const std::string& tituloSerie, const std::string& genero);

    std::string getTituloSerie() const;

    void mostrarEpisodiosDeSerie(std::string, std::vector<Episodio*>, double);

    void agregarEpisodio(const Episodio& episodio);
    void mostrarSerie() const;

    double calcularCalificacionPromedio() const;
};

#endif
